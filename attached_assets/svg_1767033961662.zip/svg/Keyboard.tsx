import type { SVGProps } from "react"
const Keyboard = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M2 7a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V7Zm3-1a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H5Zm4 8a1 1 0 0 1 1-1h4a1 1 0 1 1 0 2h-4a1 1 0 0 1-1-1Zm-2.46-2.89a1.11 1.11 0 1 0 0-2.22 1.11 1.11 0 0 0 0 2.22Zm3.64 0a1.11 1.11 0 1 0 0-2.22 1.11 1.11 0 0 0 0 2.22ZM14.93 10a1.11 1.11 0 1 1-2.22 0 1.11 1.11 0 0 1 2.22 0Zm2.53 1.11a1.11 1.11 0 1 0 0-2.22 1.11 1.11 0 0 0 0 2.22ZM7.65 14a1.11 1.11 0 1 1-2.22 0 1.11 1.11 0 0 1 2.22 0Zm10.92 0a1.11 1.11 0 1 1-2.22 0 1.11 1.11 0 0 1 2.22 0Z"
      clipRule="evenodd"
    />
  </svg>
)
export default Keyboard
