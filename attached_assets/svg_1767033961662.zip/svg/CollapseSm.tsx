import type { SVGProps } from "react"
const CollapseSm = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M5 14C5 13.4477 5.44772 13 6 13H10C10.5523 13 11 13.4477 11 14V18C11 18.5523 10.5523 19 10 19C9.44771 19 9 18.5523 9 18V15H6C5.44772 15 5 14.5523 5 14Z"
      fill="currentColor"
    />
    <path
      d="M14 5C14.5523 5 15 5.44772 15 6V9H18C18.5523 9 19 9.44771 19 10C19 10.5523 18.5523 11 18 11H14C13.4477 11 13 10.5523 13 10V6C13 5.44772 13.4477 5 14 5Z"
      fill="currentColor"
    />
  </svg>
)
export default CollapseSm
