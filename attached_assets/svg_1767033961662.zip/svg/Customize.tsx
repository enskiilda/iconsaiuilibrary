import type { SVGProps } from "react"
const Customize = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M14.5 4a5.5 5.5 0 0 0-5.078 7.616 1 1 0 0 1-.216 1.092l-4.749 4.75a1.475 1.475 0 0 0 2.086 2.085l4.749-4.749a1 1 0 0 1 1.092-.216A5.5 5.5 0 0 0 20 9.414l-1.293 1.293a3.828 3.828 0 1 1-5.414-5.414L14.585 4H14.5ZM7 9.5a7.5 7.5 0 0 1 9.969-7.084 1 1 0 0 1 .378 1.651l-2.64 2.64a1.829 1.829 0 0 0 2.586 2.586l2.64-2.64a1 1 0 0 1 1.651.378 7.5 7.5 0 0 1-9.328 9.627l-4.299 4.3a3.475 3.475 0 0 1-4.914-4.915l4.299-4.299A7.497 7.497 0 0 1 7 9.5Z"
      clipRule="evenodd"
    />
  </svg>
)
export default Customize
