import type { SVGProps } from "react"
const BranchAlt = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M19 14a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 1 1 0-2h2.495l-3.66-3.253a1 1 0 1 1 1.33-1.494L18 17.663V15a1 1 0 0 1 1-1Zm0-11a1 1 0 0 1 1 1v5a1 1 0 1 1-2 0V6.414l-4.605 4.607c-.59.588-.995 1.002-1.483 1.301a4.61 4.61 0 0 1-1.329.551c-.556.134-1.136.127-1.969.127H3a1 1 0 1 1 0-2h5.614c.928 0 1.23-.007 1.502-.072.265-.064.519-.168.751-.31.24-.147.456-.356 1.112-1.013L16.587 5H14a1 1 0 1 1 0-2h5Z" />
  </svg>
)
export default BranchAlt
