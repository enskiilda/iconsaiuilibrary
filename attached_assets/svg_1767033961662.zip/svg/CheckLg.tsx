import type { SVGProps } from "react"
const CheckLg = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M20.3215 4.17948C20.7747 4.49511 20.8862 5.11837 20.5706 5.57158L10.8206 19.5716C10.6514 19.8145 10.3833 19.97 10.0884 19.9962C9.79354 20.0223 9.50222 19.9165 9.29289 19.7072L3.54289 13.9572C3.15237 13.5667 3.15237 12.9335 3.54289 12.543C3.93342 12.1525 4.56658 12.1525 4.95711 12.543L9.86223 17.4481L18.9294 4.42859C19.245 3.97539 19.8683 3.86385 20.3215 4.17948Z"
      fill="currentColor"
    />
  </svg>
)
export default CheckLg
