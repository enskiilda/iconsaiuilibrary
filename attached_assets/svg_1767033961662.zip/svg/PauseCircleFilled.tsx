import type { SVGProps } from "react"
const PauseCircleFilled = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM8.25 9.25V14.75C8.25 15.5523 8.69772 15.75 9.25 15.75H10C10.5523 15.75 11 15.5523 11 14.75V9.25C11 8.69772 10.5523 8.25 10 8.25H9.25C8.69772 8.25 8.25 8.69772 8.25 9.25ZM14 8.25C13.4477 8.25 13 8.69772 13 9.25V14.75C13 15.5523 13.4477 15.75 14 15.75H14.75C15.3023 15.75 15.75 15.5523 15.75 14.75V9.25C15.75 8.69772 15.3023 8.25 14.75 8.25H14Z"
      fill="currentColor"
    />
  </svg>
)
export default PauseCircleFilled
