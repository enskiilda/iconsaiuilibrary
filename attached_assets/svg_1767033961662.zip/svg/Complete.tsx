import type { SVGProps } from "react"
const Complete = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M18.345 5.26068C19.0295 5.72737 19.206 6.66056 18.7393 7.34503L11.2393 18.345C10.9877 18.7141 10.5847 18.9518 10.14 18.9935C9.69533 19.0352 9.25517 18.8765 8.93934 18.5607L4.43934 14.0607C3.85355 13.4749 3.85355 12.5251 4.43934 11.9394C5.02513 11.3536 5.97487 11.3536 6.56066 11.9394L9.78052 15.1592L16.2607 5.65502C16.7273 4.97055 17.6605 4.794 18.345 5.26068Z"
      fill="currentColor"
    />
  </svg>
)
export default Complete
