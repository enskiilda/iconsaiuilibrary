import type { SVGProps } from "react"
const Plus14px = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M12 5C12.5799 5 13.05 5.4701 13.05 6.05V10.95H17.95C18.5299 10.95 19 11.4201 19 12C19 12.5799 18.5299 13.05 17.95 13.05H13.05V17.95C13.05 18.5299 12.5799 19 12 19C11.4201 19 10.95 18.5299 10.95 17.95V13.05H6.05C5.4701 13.05 5 12.5799 5 12C5 11.4201 5.4701 10.95 6.05 10.95H10.95V6.05C10.95 5.4701 11.4201 5 12 5Z"
      fill="currentColor"
    />
  </svg>
)
export default Plus14px
