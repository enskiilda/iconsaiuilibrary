import type { SVGProps } from "react"
const Connect = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M6.346 10.897A3.5 3.5 0 1 1 8.856 6.5h6.289A3.502 3.502 0 0 1 22 7.5a3.5 3.5 0 0 1-4.346 3.397l-3.087 5.224a3.5 3.5 0 1 1-5.135 0l-3.086-5.224ZM4 7.5a1.5 1.5 0 1 1 2.418 1.187 1.006 1.006 0 0 0-.322.19A1.5 1.5 0 0 1 4 7.5Zm4.067 2.379 3.087 5.224a3.508 3.508 0 0 1 1.692 0l3.087-5.224a3.496 3.496 0 0 1-.788-1.379h-6.29c-.155.52-.428.99-.788 1.379Zm9.997-.943a.998.998 0 0 0-.61-.362 1.5 1.5 0 1 1 .61.361ZM12 17a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z"
      clipRule="evenodd"
    />
  </svg>
)
export default Connect
