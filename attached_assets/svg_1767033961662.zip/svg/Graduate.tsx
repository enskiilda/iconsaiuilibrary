import type { SVGProps } from "react"
const Graduate = (props: SVGProps<SVGSVGElement>) => (
  <svg
    fill="currentColor"
    stroke="currentColor"
    viewBox="0 0 21 21"
    width="1em"
    height="1em"
    {...props}
  >
    <path
      d="M4.05 8.956a50.363 50.363 0 0 0-.41 5.289 40.521 40.521 0 0 1 6.86 3.675 40.517 40.517 0 0 1 6.86-3.675 50.374 50.374 0 0 0-.41-5.29m0 0c.73-.244 1.47-.471 2.216-.678A49.919 49.919 0 0 0 10.5 3.411a49.921 49.921 0 0 0-8.666 4.867 42.206 42.206 0 0 1 8.666 3.463 42.265 42.265 0 0 1 6.45-2.785ZM6.126 13a.625.625 0 1 0 0-1.25.625.625 0 0 0 0 1.25Zm0 0V9.937A46.148 46.148 0 0 1 10.5 7.536M4.66 17.16a4.984 4.984 0 0 0 1.465-3.536v-1.25"
      strokeWidth={1.25}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
)
export default Graduate
