import type { SVGProps } from "react"
const Mail = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M5 4a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H5ZM4 7.329V17a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V7.329L13.976 12.6a3 3 0 0 1-3.952 0L4 7.33ZM18.481 6H5.52l5.822 5.095a1 1 0 0 0 1.318 0L18.48 6Z"
      clipRule="evenodd"
    />
  </svg>
)
export default Mail
