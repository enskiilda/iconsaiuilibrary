import type { SVGProps } from "react"
const HeartFilledXs = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 18 18" fill="currentColor" {...props}>
    <path
      d="M9.4802 16.2523C16.254 12.5465 18.0637 8.04631 16.7198 4.77563C16.0734 3.20251 14.7201 2.08229 13.1328 1.73684C11.7752 1.44137 10.2982 1.72257 9.0002 2.67759C7.70222 1.72257 6.22522 1.44137 4.86756 1.73684C3.28026 2.08229 1.92697 3.20252 1.28061 4.77565C-0.0632352 8.04633 1.74643 12.5465 8.52029 16.2523C8.81935 16.4159 9.18114 16.4159 9.4802 16.2523Z"
      fill="currentColor"
    />
  </svg>
)
export default HeartFilledXs
