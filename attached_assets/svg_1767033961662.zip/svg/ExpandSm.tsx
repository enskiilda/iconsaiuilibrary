import type { SVGProps } from "react"
const ExpandSm = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M12 7C12 6.44772 12.4477 6 13 6H17C17.5523 6 18 6.44772 18 7V11C18 11.5523 17.5523 12 17 12C16.4477 12 16 11.5523 16 11V8H13C12.4477 8 12 7.55228 12 7ZM7 12C7.55228 12 8 12.4477 8 13V16H11C11.5523 16 12 16.4477 12 17C12 17.5523 11.5523 18 11 18H7C6.44772 18 6 17.5523 6 17V13C6 12.4477 6.44772 12 7 12Z"
      fill="currentColor"
    />
  </svg>
)
export default ExpandSm
