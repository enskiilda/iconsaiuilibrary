import type { SVGProps } from "react"
const Education = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M11.521 2.122a1 1 0 0 1 .958 0l11 6A1 1 0 0 1 24 9v6a1 1 0 1 1-2 0v-4.316l-2.033 1.11v4.511a3 3 0 0 1-1.578 2.642l-4.967 2.673a3 3 0 0 1-2.844 0l-4.967-2.673a3 3 0 0 1-1.578-2.642v-4.511L.521 9.878a1 1 0 0 1 0-1.756l11-6Zm-5.993 8.209a1.058 1.058 0 0 0-.034-.019L3.088 9 12 4.14 20.912 9l-2.406 1.312a1.13 1.13 0 0 0-.035.019L12 13.861l-6.472-3.53Zm.505 2.553v3.421a1 1 0 0 0 .526.88l4.967 2.674a1 1 0 0 0 .948 0l4.967-2.673a1 1 0 0 0 .526-.88v-3.422l-5.488 2.994a1 1 0 0 1-.958 0l-5.488-2.994Z"
      clipRule="evenodd"
    />
  </svg>
)
export default Education
