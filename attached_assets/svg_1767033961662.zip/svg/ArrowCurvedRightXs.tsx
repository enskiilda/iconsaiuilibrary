import type { SVGProps } from "react"
const ArrowCurvedRightXs = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M7 7a1 1 0 0 1 1 1c0 .713 0 1.197.026 1.573.025.368.07.559.126.692a2 2 0 0 0 1.083 1.083c.133.055.324.1.692.126.376.025.86.026 1.573.026h3.086l-1.293-1.293a1 1 0 0 1 1.414-1.414l3 3a1 1 0 0 1 0 1.414l-3 3a1 1 0 0 1-1.414-1.414l1.293-1.293h-3.12c-.67 0-1.223 0-1.676-.03-.469-.033-.903-.101-1.32-.275a4 4 0 0 1-2.166-2.164c-.173-.418-.241-.852-.273-1.321C6 9.257 6 8.704 6 8.034V8a1 1 0 0 1 1-1Z" />
  </svg>
)
export default ArrowCurvedRightXs
