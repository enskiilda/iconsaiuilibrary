import type { SVGProps } from "react"
const BarChartFilled = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M2 10.5C2 9.67157 2.67157 9 3.5 9H5.83C6.65843 9 7.33 9.67157 7.33 10.5V18.5C7.33 19.3284 6.65843 20 5.83 20H3.5C2.67157 20 2 19.3284 2 18.5V10.5Z"
      fill="currentColor"
    />
    <path
      d="M16.67 8.5C16.67 7.67157 17.3416 7 18.17 7H20.5C21.3284 7 22 7.67157 22 8.5V18.5C22 19.3284 21.3284 20 20.5 20H18.17C17.3416 20 16.67 19.3284 16.67 18.5V8.5Z"
      fill="currentColor"
    />
    <path
      d="M9.33 4.5C9.33 3.67157 10.0016 3 10.83 3H13.17C13.9984 3 14.67 3.67157 14.67 4.5V19C14.67 19.5523 14.2223 20 13.67 20H10.33C9.77772 20 9.33 19.5523 9.33 19V4.5Z"
      fill="currentColor"
    />
  </svg>
)
export default BarChartFilled
