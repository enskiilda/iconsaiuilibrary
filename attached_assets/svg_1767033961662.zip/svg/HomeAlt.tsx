import type { SVGProps } from "react"
const HomeAlt = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M10.436 3.284a3 3 0 0 1 3.129 0l7.957 4.863a1 1 0 0 1-1.043 1.706L20 9.561V17a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V9.56l-.478.293a1 1 0 0 1-1.043-1.706l7.957-4.863ZM6 8.338V17a1 1 0 0 0 1 1h2v-2a3 3 0 1 1 6 0v2h2a1 1 0 0 0 1-1V8.338L12.522 4.99a1 1 0 0 0-1.043 0L6 8.338ZM13 18v-2a1 1 0 1 0-2 0v2h2Z"
      clipRule="evenodd"
    />
  </svg>
)
export default HomeAlt
