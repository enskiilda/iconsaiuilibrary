import type { SVGProps } from "react"
const HandRaised = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M10.25 4a.75.75 0 0 0-.75.75V10a1 1 0 1 1-2 0V6.75a.75.75 0 0 0-1.5 0V14a6 6 0 0 0 12 0V9.333A.333.333 0 0 0 17.667 9C16.747 9 16 9.746 16 10.667V12.5a1 1 0 0 1-.684.949l-.628.21A2.469 2.469 0 0 0 13 16a1 1 0 1 1-2 0 4.469 4.469 0 0 1 3-4.22v-1.113c0-.675.182-1.307.5-1.85V5.75a.75.75 0 0 0-1.5 0V9a1 1 0 1 1-2 0V4.75a.75.75 0 0 0-.75-.75Zm2.316-.733A2.75 2.75 0 0 1 16.5 5.75v1.44A3.66 3.66 0 0 1 17.667 7 2.333 2.333 0 0 1 20 9.333V14a8 8 0 1 1-16 0V6.75a2.75 2.75 0 0 1 3.571-2.625 2.751 2.751 0 0 1 4.995-.858Z"
      clipRule="evenodd"
    />
  </svg>
)
export default HandRaised
