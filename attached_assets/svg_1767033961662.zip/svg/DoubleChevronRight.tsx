import type { SVGProps } from "react"
const DoubleChevronRight = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M5.327 5.76a1 1 0 0 1 1.413.067l5 5.5a1 1 0 0 1 0 1.346l-5 5.5a1 1 0 1 1-1.48-1.346L9.65 12 5.26 7.173a1 1 0 0 1 .067-1.413Zm8 0a1 1 0 0 1 1.413.067l5 5.5a1 1 0 0 1 0 1.346l-5 5.5a1 1 0 1 1-1.48-1.346L17.648 12 13.26 7.173a1 1 0 0 1 .067-1.413Z"
      clipRule="evenodd"
    />
  </svg>
)
export default DoubleChevronRight
