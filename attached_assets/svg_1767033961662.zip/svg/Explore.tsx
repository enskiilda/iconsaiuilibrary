import type { SVGProps } from "react"
const Explore = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      fillRule="evenodd"
      d="M4 12a8 8 0 1 1 16 0 8 8 0 0 1-16 0Zm8-10C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2Zm4.465 6.763a1 1 0 0 0-1.228-1.228l-5.5 1.5a1 1 0 0 0-.702.702l-1.5 5.5a1 1 0 0 0 1.228 1.228l5.5-1.5a1 1 0 0 0 .702-.702l1.5-5.5Zm-6.54 5.312.89-3.26 3.26-.89-.89 3.26-3.26.89Z"
      clipRule="evenodd"
    />
  </svg>
)
export default Explore
