import type { SVGProps } from "react"
const MapsDirections = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M14.5321 18.4159L19.0209 5.69756C19.3005 4.90533 18.5376 4.14239 17.7453 4.422L5.02696 8.91084C4.18269 9.20882 4.12559 10.381 4.93691 10.7597L9.88904 13.0707C10.1019 13.17 10.2729 13.341 10.3722 13.5539L12.6832 18.506C13.0619 19.3173 14.2341 19.2602 14.5321 18.4159Z"
      fill="currentColor"
    />
  </svg>
)
export default MapsDirections
