import type { SVGProps } from "react"
const NotebookPencil = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M11 5V3a1 1 0 1 1 2 0v2a1 1 0 1 1-2 0Zm4 0V3a1 1 0 1 1 2 0v2a1 1 0 1 1-2 0ZM7 5V3a1 1 0 0 1 2 0v2a1 1 0 0 1-2 0Zm10.281 9.63a2.892 2.892 0 0 1 4.09 0l.198.22a2.892 2.892 0 0 1-.198 3.87l-3.986 3.987a1 1 0 0 1-.707.293h-2.676a1 1 0 0 1-1-1v-2.676l.005-.098a1 1 0 0 1 .288-.609l3.986-3.986Zm2.676 1.415a.892.892 0 0 0-1.262 0l-3.693 3.693V21h1.262l3.693-3.693a.893.893 0 0 0 .062-1.195l-.062-.067Z" />
    <path d="M18 10.5V6a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1h2a1 1 0 1 1 0 2H7a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3v4.5a1 1 0 1 1-2 0Z" />
    <path d="M15 9a1 1 0 1 1 0 2H9a1 1 0 1 1 0-2h6Zm-3 4a1 1 0 1 1 0 2H9a1 1 0 1 1 0-2h3Z" />
  </svg>
)
export default NotebookPencil
