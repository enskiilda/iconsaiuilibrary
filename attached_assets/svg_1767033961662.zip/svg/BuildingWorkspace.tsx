import type { SVGProps } from "react"
const BuildingWorkspace = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M3 6C3 4.34315 4.34315 3 6 3H12C13.6569 3 15 4.34315 15 6V7H18C19.6569 7 21 8.34315 21 10V19H22C22.5523 19 23 19.4477 23 20C23 20.5523 22.5523 21 22 21H2C1.44772 21 1 20.5523 1 20C1 19.4477 1.44772 19 2 19H3V6ZM5 19H8V17C8 16.4477 8.44772 16 9 16C9.55228 16 10 16.4477 10 17V19H13V6C13 5.44772 12.5523 5 12 5H6C5.44772 5 5 5.44772 5 6V19ZM15 19H19V10C19 9.44772 18.5523 9 18 9H15V19Z"
      fill="currentColor"
    />
  </svg>
)
export default BuildingWorkspace
