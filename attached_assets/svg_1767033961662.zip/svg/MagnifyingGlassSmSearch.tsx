import type { SVGProps } from "react"
const MagnifyingGlassSmSearch = (props: SVGProps<SVGSVGElement>) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path
      d="M10.5 5.5C7.73858 5.5 5.5 7.73858 5.5 10.5C5.5 13.2614 7.73858 15.5 10.5 15.5C13.2614 15.5 15.5 13.2614 15.5 10.5C15.5 7.73858 13.2614 5.5 10.5 5.5ZM3.5 10.5C3.5 6.63401 6.63401 3.5 10.5 3.5C14.366 3.5 17.5 6.63401 17.5 10.5C17.5 12.0723 16.9816 13.5236 16.1064 14.6922L19.7071 18.2929C20.0976 18.6834 20.0976 19.3166 19.7071 19.7071C19.3166 20.0976 18.6834 20.0976 18.2929 19.7071L14.6922 16.1064C13.5236 16.9816 12.0723 17.5 10.5 17.5C6.63401 17.5 3.5 14.366 3.5 10.5Z"
      fill="currentColor"
    />
  </svg>
)
export default MagnifyingGlassSmSearch
